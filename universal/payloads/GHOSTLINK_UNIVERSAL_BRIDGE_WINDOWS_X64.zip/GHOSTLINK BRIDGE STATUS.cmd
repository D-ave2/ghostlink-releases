@echo off
title GHOSTLINK BRIDGE // STATUS
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\bridge-status.ps1"
echo.
pause
