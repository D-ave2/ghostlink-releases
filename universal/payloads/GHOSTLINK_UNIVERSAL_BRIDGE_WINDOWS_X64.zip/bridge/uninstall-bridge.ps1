$ErrorActionPreference = "SilentlyContinue"

$root = Join-Path $env:LOCALAPPDATA "GHOSTLINK\bridge"
$startup = [Environment]::GetFolderPath("Startup")
$link = Join-Path $startup "GHOSTLINK Bridge.lnk"

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
    Where-Object { $_.CommandLine -like "*ghostlink-bridge.ps1*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

Remove-Item -LiteralPath $link -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "GHOSTLINK Bridge removed." -ForegroundColor Green
Write-Host "The main GHOSTLINK app, EQ profiles, and DOWNLOAD command were left untouched."
