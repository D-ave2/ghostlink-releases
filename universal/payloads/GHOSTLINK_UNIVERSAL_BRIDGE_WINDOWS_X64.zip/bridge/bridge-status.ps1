$ErrorActionPreference = "SilentlyContinue"
$root = Join-Path $env:LOCALAPPDATA "GHOSTLINK\bridge"
$state = Join-Path $root "bridge-state.json"
$log = Join-Path $root "bridge.log"
$launcher = Join-Path $root "download-launcher.ps1"

Write-Host ""
Write-Host "GHOSTLINK UNIVERSAL BRIDGE // STATUS" -ForegroundColor Cyan
Write-Host "------------------------------------" -ForegroundColor DarkGray
Write-Host ("Universal launcher : " + $(if(Test-Path -LiteralPath $launcher){"READY"}else{"MISSING"}))

if (Test-Path -LiteralPath $state) {
    $s = Get-Content -LiteralPath $state -Raw | ConvertFrom-Json
    Write-Host ("Connected          : " + $s.connected)
    Write-Host ("MAC match          : " + $s.mac_match)
    Write-Host ("Identity count     : " + $s.identity_count)
    Write-Host ("Stereo count       : " + $s.stereo_count)
    Write-Host ("Stereo endpoint    : " + (($s.stereo_names) -join ", "))
    Write-Host ("Last probe         : " + $s.last_seen)
} else {
    Write-Host "No bridge state file yet." -ForegroundColor Yellow
}

Write-Host ""
if (Test-Path -LiteralPath $log) {
    Write-Host "LATEST BRIDGE LOG" -ForegroundColor Cyan
    Get-Content -LiteralPath $log -Tail 12
}
