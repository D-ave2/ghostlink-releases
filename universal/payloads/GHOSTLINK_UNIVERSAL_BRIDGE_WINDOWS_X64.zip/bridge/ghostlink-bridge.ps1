param(
    [int]$PollSeconds = 2
)

$ErrorActionPreference = "Stop"

$Root = Join-Path $env:LOCALAPPDATA "GHOSTLINK\bridge"
$Log  = Join-Path $Root "bridge.log"
$StateFile = Join-Path $Root "bridge-state.json"
$App = Join-Path $env:LOCALAPPDATA "GHOSTLINK\app\GHOSTLINK.exe"
$ExpectedMac = "907E9653AAC4"

New-Item -ItemType Directory -Force $Root | Out-Null

function Write-BridgeLog([string]$Message) {
    try {
        if (Test-Path -LiteralPath $Log) {
            $fi = Get-Item -LiteralPath $Log -ErrorAction SilentlyContinue
            if ($fi -and $fi.Length -gt 1048576) {
                Move-Item -LiteralPath $Log -Destination ($Log + ".old") -Force -ErrorAction SilentlyContinue
            }
        }
        $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Add-Content -LiteralPath $Log -Value "[$stamp] $Message" -Encoding UTF8
    } catch {}
}

function Show-BridgeNotice([string]$Title, [string]$Text) {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        $n = New-Object System.Windows.Forms.NotifyIcon
        $n.Icon = [System.Drawing.SystemIcons]::Information
        $n.BalloonTipTitle = $Title
        $n.BalloonTipText = $Text
        $n.Visible = $true
        $n.ShowBalloonTip(5000)
        Start-Sleep -Milliseconds 5500
        $n.Dispose()
    } catch {
        Write-BridgeLog "Notification fallback: $Title // $Text"
    }
}

function Get-GhostlinkPresence {
    $all = @()
    $audio = @()

    try {
        $all = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue)
    } catch {
        Write-BridgeLog ("PnP present-only probe failed: " + $_.Exception.Message)
    }

    try {
        $audio = @(Get-PnpDevice -Class AudioEndpoint -PresentOnly -ErrorAction SilentlyContinue)
    } catch {
        Write-BridgeLog ("AudioEndpoint probe failed: " + $_.Exception.Message)
    }

    $macMatches = @(
        $all | Where-Object {
            (($_.InstanceId -replace '[^0-9A-Fa-f]','').ToUpperInvariant()).Contains($ExpectedMac)
        }
    )

    $identityMatches = @(
        $all | Where-Object {
            $_.FriendlyName -and (
                $_.FriendlyName -match '(?i)JBL-800' -or
                $_.FriendlyName -match '(?i)GHOSTLINK'
            )
        }
    )

    $stereoMatches = @(
        $audio | Where-Object {
            $_.FriendlyName -and
            $_.Status -eq 'OK' -and
            $_.FriendlyName -notmatch '(?i)Hands-Free|Hands Free|Headset' -and
            (
                $_.FriendlyName -match '(?i)JBL-800' -or
                $_.FriendlyName -match '(?i)GHOSTLINK'
            )
        }
    )

    $identityOk = ($macMatches.Count -gt 0 -or $identityMatches.Count -gt 0)
    $stereoOk = ($stereoMatches.Count -gt 0)

    [pscustomobject]@{
        Connected = ($identityOk -and $stereoOk)
        MacMatch = ($macMatches.Count -gt 0)
        IdentityCount = $identityMatches.Count
        StereoCount = $stereoMatches.Count
        StereoNames = @($stereoMatches | ForEach-Object { $_.FriendlyName })
    }
}

function Save-BridgeState($presence) {
    try {
        [pscustomobject]@{
            connected = [bool]$presence.Connected
            mac_match = [bool]$presence.MacMatch
            identity_count = [int]$presence.IdentityCount
            stereo_count = [int]$presence.StereoCount
            stereo_names = @($presence.StereoNames)
            last_seen = (Get-Date).ToString("o")
        } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $StateFile -Encoding UTF8
    } catch {}
}

function Start-GhostlinkApp {
    if (-not (Test-Path -LiteralPath $App)) {
        return $false
    }

    try {
        $already = @(Get-Process -Name "GHOSTLINK" -ErrorAction SilentlyContinue)
        if ($already.Count -eq 0) {
            Start-Process -FilePath $App -WorkingDirectory (Split-Path -Parent $App) | Out-Null
            Write-BridgeLog "GHOSTLINK app launched."
        } else {
            Write-BridgeLog "GHOSTLINK app already running."
        }
        return $true
    } catch {
        Write-BridgeLog ("App launch failed: " + $_.Exception.Message)
        return $false
    }
}

$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, "Local\GHOSTLINK_BRIDGE_V1", [ref]$createdNew)
if (-not $createdNew) {
    exit 0
}

Write-BridgeLog "============================================================"
Write-BridgeLog "GHOSTLINK BRIDGE v0.1.0 started. Expected MAC=$ExpectedMac"

$lastConnected = $null

try {
    while ($true) {
        $presence = Get-GhostlinkPresence
        Save-BridgeState $presence

        if ($null -eq $lastConnected) {
            $lastConnected = [bool]$presence.Connected
            if ($presence.Connected) {
                Write-BridgeLog ("Startup detection ONLINE. MAC=" + $presence.MacMatch + " Stereo=" + ($presence.StereoNames -join ', '))
                if (Start-GhostlinkApp) {
                    Show-BridgeNotice "GHOSTLINK DEVICE DETECTED" "Bridge recognized JBL-800 / GHOSTLINK. Control Center launched."
                } else {
                    Show-BridgeNotice "GHOSTLINK DEVICE DETECTED" "Bridge is ready. Open PowerShell and run DOWNLOAD GHOSTLINK."
                }
            } else {
                Write-BridgeLog "Startup detection OFFLINE."
            }
        }
        elseif ([bool]$presence.Connected -ne [bool]$lastConnected) {
            $lastConnected = [bool]$presence.Connected

            if ($presence.Connected) {
                Write-BridgeLog ("Transition OFFLINE -> ONLINE. MAC=" + $presence.MacMatch + " Stereo=" + ($presence.StereoNames -join ', '))
                if (Start-GhostlinkApp) {
                    Show-BridgeNotice "GHOSTLINK DEVICE DETECTED" "JBL-800 / GHOSTLINK connected. Control Center launched."
                } else {
                    Show-BridgeNotice "GHOSTLINK DEVICE DETECTED" "Headset recognized. Run DOWNLOAD GHOSTLINK to install the full system."
                }
            } else {
                Write-BridgeLog "Transition ONLINE -> OFFLINE."
                Show-BridgeNotice "GHOSTLINK OFFLINE" "JBL-800 / GHOSTLINK disconnected."
            }
        }

        Start-Sleep -Seconds ([Math]::Max(1, $PollSeconds))
    }
}
catch {
    Write-BridgeLog ("Bridge main loop recovered from fatal error: " + $_.Exception.Message)
}
finally {
    try { $mutex.ReleaseMutex() | Out-Null } catch {}
    try { $mutex.Dispose() } catch {}
}
