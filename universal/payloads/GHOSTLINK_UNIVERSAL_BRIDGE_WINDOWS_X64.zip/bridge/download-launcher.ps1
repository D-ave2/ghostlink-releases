param(
    [string]$RequestedName = "GHOSTLINK"
)

$ErrorActionPreference = "Stop"

$GhostRoot  = Join-Path $env:LOCALAPPDATA "GHOSTLINK"
$OnlineRoot = Join-Path $GhostRoot "online"
$Engine     = Join-Path $OnlineRoot "ghostlink-online.ps1"
$TempEngine = Join-Path $OnlineRoot "ghostlink-online.new.ps1"
$EngineUrl  = "https://raw.githubusercontent.com/D-ave2/ghostlink-releases/main/bootstrap/ghostlink-online.ps1"

function Is-Administrator {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Relaunch-Elevated {
    $quotedScript = '"' + $PSCommandPath + '"'
    $args = "-NoProfile -ExecutionPolicy Bypass -File $quotedScript -RequestedName GHOSTLINK"
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $args | Out-Null
}

try {
    if ($RequestedName -ne "GHOSTLINK") {
        Write-Host "Usage: DOWNLOAD GHOSTLINK" -ForegroundColor Yellow
        exit 1
    }

    if (-not (Is-Administrator)) {
        Relaunch-Elevated
        exit 0
    }

    New-Item -ItemType Directory -Force -Path $OnlineRoot | Out-Null

    Write-Host ""
    Write-Host "GHOSTLINK // UNIVERSAL COMMAND ENGINE" -ForegroundColor Cyan
    Write-Host "Refreshing online installer engine..." -ForegroundColor DarkGray

    $refreshed = $false
    try {
        Remove-Item -LiteralPath $TempEngine -Force -ErrorAction SilentlyContinue

        Invoke-WebRequest `
            -UseBasicParsing `
            -Uri $EngineUrl `
            -OutFile $TempEngine

        if (-not (Test-Path -LiteralPath $TempEngine)) {
            throw "Online engine download did not produce a file."
        }

        $length = (Get-Item -LiteralPath $TempEngine).Length
        if ($length -lt 500) {
            throw "Downloaded online engine is unexpectedly small."
        }

        Move-Item -LiteralPath $TempEngine -Destination $Engine -Force
        $refreshed = $true
        Write-Host "Online engine => REFRESHED" -ForegroundColor Green
    }
    catch {
        Remove-Item -LiteralPath $TempEngine -Force -ErrorAction SilentlyContinue

        if (Test-Path -LiteralPath $Engine) {
            Write-Host "Online refresh unavailable; using verified local engine cache." -ForegroundColor Yellow
        }
        else {
            throw "Could not download the GHOSTLINK online engine and no cached engine exists. " + $_.Exception.Message
        }
    }

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Engine -RequestedName GHOSTLINK
    $rc = $LASTEXITCODE
    exit $rc
}
catch {
    Write-Host ""
    Write-Host "GHOSTLINK command engine failed." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
