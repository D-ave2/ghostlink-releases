$ErrorActionPreference = "Stop"

$SourceBridge = Join-Path $PSScriptRoot "ghostlink-bridge.ps1"
$SourceLauncher = Join-Path $PSScriptRoot "download-launcher.ps1"

$GhostRoot = Join-Path $env:LOCALAPPDATA "GHOSTLINK"
$BridgeRoot = Join-Path $GhostRoot "bridge"
$BinRoot = Join-Path $GhostRoot "bin"

$InstalledBridge = Join-Path $BridgeRoot "ghostlink-bridge.ps1"
$InstalledLauncher = Join-Path $BridgeRoot "download-launcher.ps1"
$DownloadCmd = Join-Path $BinRoot "DOWNLOAD.cmd"

function Step([string]$Text) {
    Write-Host ""
    Write-Host ">>> $Text" -ForegroundColor Cyan
}

function Fail([string]$Text) {
    Write-Host ""
    Write-Host "GHOSTLINK BRIDGE INSTALL FAILED" -ForegroundColor Red
    Write-Host $Text -ForegroundColor Red
    exit 1
}

try {
    Step "Universal Bridge preflight"

    if (-not [Environment]::Is64BitOperatingSystem) {
        Fail "This release currently targets 64-bit Windows."
    }

    if (-not (Test-Path -LiteralPath $SourceBridge)) {
        Fail "Bridge watcher payload is missing."
    }

    if (-not (Test-Path -LiteralPath $SourceLauncher)) {
        Fail "Universal DOWNLOAD launcher payload is missing."
    }

    New-Item -ItemType Directory -Force -Path $BridgeRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $BinRoot | Out-Null

    Copy-Item -LiteralPath $SourceBridge -Destination $InstalledBridge -Force
    Copy-Item -LiteralPath $SourceLauncher -Destination $InstalledLauncher -Force

    Step "Registering universal DOWNLOAD GHOSTLINK command"

    $cmd = @'
@echo off
setlocal
if /I not "%~1"=="GHOSTLINK" (
  echo Usage: DOWNLOAD GHOSTLINK
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\GHOSTLINK\bridge\download-launcher.ps1" -RequestedName GHOSTLINK
exit /b %ERRORLEVEL%
'@

    [IO.File]::WriteAllText($DownloadCmd, $cmd, [Text.Encoding]::ASCII)

    $userPath = [Environment]::GetEnvironmentVariable("Path","User")
    $parts = @()
    if ($userPath) {
        $parts = @($userPath -split ';' | Where-Object { $_ })
    }

    if ($parts -notcontains $BinRoot) {
        [Environment]::SetEnvironmentVariable("Path", (($parts + $BinRoot) -join ';'), "User")
    }

    if (($env:Path -split ';') -notcontains $BinRoot) {
        $env:Path = "$BinRoot;$env:Path"
    }

    Step "Registering automatic headset recognition"

    $startup = [Environment]::GetFolderPath("Startup")
    $shortcutPath = Join-Path $startup "GHOSTLINK Bridge.lnk"

    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($shortcutPath)
    $sc.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $sc.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstalledBridge`""
    $sc.WorkingDirectory = $BridgeRoot
    $sc.WindowStyle = 7
    $sc.Description = "GHOSTLINK Bridge"
    $sc.Save()

    Step "Restarting Bridge watcher"

    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like "*ghostlink-bridge.ps1*" } |
        ForEach-Object {
            if ($_.ProcessId -ne $PID) {
                Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
            }
        }

    Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" `
        -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstalledBridge`"" `
        -WindowStyle Hidden | Out-Null

    Start-Sleep -Seconds 2

    Step "Verification"

    $bridgeReady = Test-Path -LiteralPath $InstalledBridge
    $launcherReady = Test-Path -LiteralPath $InstalledLauncher
    $downloadReady = Test-Path -LiteralPath $DownloadCmd
    $startupReady = Test-Path -LiteralPath $shortcutPath

    Write-Host ("Bridge watcher     => " + $(if($bridgeReady){"READY"}else{"MISSING"})) -ForegroundColor $(if($bridgeReady){"Green"}else{"Red"})
    Write-Host ("Universal launcher => " + $(if($launcherReady){"READY"}else{"MISSING"})) -ForegroundColor $(if($launcherReady){"Green"}else{"Red"})
    Write-Host ("DOWNLOAD command   => " + $(if($downloadReady){"READY"}else{"MISSING"})) -ForegroundColor $(if($downloadReady){"Green"}else{"Red"})
    Write-Host ("Automatic startup  => " + $(if($startupReady){"READY"}else{"MISSING"})) -ForegroundColor $(if($startupReady){"Green"}else{"Red"})

    if (-not ($bridgeReady -and $launcherReady -and $downloadReady -and $startupReady)) {
        Fail "One or more Universal Bridge verification gates failed."
    }

    Write-Host ""
    Write-Host "GHOSTLINK UNIVERSAL BRIDGE v1.0.0 => INSTALLED" -ForegroundColor Green
    Write-Host "Future DOWNLOAD runs refresh the online engine automatically."
}
catch {
    Fail $_.Exception.Message
}
