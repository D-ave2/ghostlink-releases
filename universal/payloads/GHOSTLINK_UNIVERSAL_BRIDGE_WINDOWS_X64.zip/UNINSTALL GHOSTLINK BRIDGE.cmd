@echo off
title GHOSTLINK BRIDGE // UNINSTALL
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\uninstall-bridge.ps1"
echo.
pause
