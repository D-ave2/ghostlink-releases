@echo off
title GHOSTLINK BRIDGE // INSTALL
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bridge\install-bridge.ps1"
echo.
pause
