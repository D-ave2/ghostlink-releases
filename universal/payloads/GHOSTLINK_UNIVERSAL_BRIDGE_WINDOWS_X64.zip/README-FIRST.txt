GHOSTLINK UNIVERSAL BRIDGE v1.0.0
==================================

GOAL
----
Keep the already-proven JBL-800 / GHOSTLINK recognition behavior while removing
fragile one-line CMD/PowerShell bootstrap logic.

IMPORTANT
---------
The headset watcher itself is preserved byte-for-byte from the proven Bridge v0.1.0.

Proven watcher SHA-256:
3131ee1866cfb9657074f3e6fdd360417824825d756c2ccdd7ed95f4f13bf85e

NEW IN UNIVERSAL BRIDGE v1
--------------------------
- DOWNLOAD.cmd is intentionally tiny.
- It calls a dedicated PowerShell 5.1-compatible download-launcher.ps1.
- Every DOWNLOAD GHOSTLINK run refreshes the online engine from GitHub first.
- If refresh is temporarily unavailable, an existing cached engine is used.
- No EQ tuning, app UI, or approved BASS values are changed.

EXPECTED HEADSET
----------------
JBL-800 / GHOSTLINK
90:7E:96:53:AA:C4
